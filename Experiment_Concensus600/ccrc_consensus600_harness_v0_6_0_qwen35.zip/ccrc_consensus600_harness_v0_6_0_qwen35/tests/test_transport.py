from harness.prompts import verifier_spec

def test_verifier_has_no_assistant_history():
    item={
        "source_id":"mmlu:test:1",
        "question":"Q?",
        "options":{"A":"a","B":"b","C":"c","D":"d"},
    }
    for branch in ["V1","V2"]:
        msgs=verifier_spec(item,branch,1)["messages"]
        assert all(m["role"]!="assistant" for m in msgs)
