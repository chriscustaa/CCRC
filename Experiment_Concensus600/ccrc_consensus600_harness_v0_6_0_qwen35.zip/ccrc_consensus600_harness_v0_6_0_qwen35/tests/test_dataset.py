from harness.dataset import permutation_safe, select_subject_balanced_unique


def test_permutation_safety():
    opts={"A":"one","B":"two","C":"three","D":"all of the above"}
    assert permutation_safe("Pick one",opts) is False
    safe={"A":"one","B":"two","C":"three","D":"four"}
    assert permutation_safe("Pick one",safe) is True


def test_subject_balanced_selection():
    qs=[]
    for s in range(57):
        for i in range(20):
            qs.append({
                "id":f"{s}:{i}",
                "source_row_index":s*100+i,
                "subject":f"s{s:02d}",
                "question":f"Unique question {s}-{i}?",
                "options":{"A":"a","B":"b","C":"c","D":"d"},
                "correct":"ABCD"[i%4],
                "permutation_safe":True,
            })
    items,audit=select_subject_balanced_unique(qs,600,123,set())
    assert len(items)==600
    counts=audit["selected_subject_counts"]
    assert max(counts.values()) - min(counts.values()) <= 1
    assert len(counts)==57
