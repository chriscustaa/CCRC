from harness.prompts import verifier_spec
from harness.runner import decision_gap
from harness.summary import _majority, _policy_metrics


def item(i=1):
    return {
        "task_id":f"T{i:04d}",
        "source_id":f"mmlu:test:{i}",
        "source_row_index":i,
        "domain":"subject",
        "difficulty":"unspecified",
        "question":"Which answer is best?",
        "options":{"A":"a","B":"b","C":"c","D":"d"},
        "correct":"A",
    }


def rec(qid, branch, answer, gt="A", gap=None):
    r={
        "question_id":qid,
        "branch":branch,
        "correct_answer":gt,
        "parsed_first":answer,
        "format_retry":None,
        "usage":{"total_tokens":10},
    }
    if gap is not None:
        r["decision_gap"]=gap
    return r


def test_decision_gap():
    assert abs(decision_gap({"A":-0.1,"B":-0.3,"C":-2.0,"D":-3.0}) - 0.2) < 1e-9


def test_verifier_permutations_distinct_and_nonidentity():
    x=item()
    v1=verifier_spec(x,"V1",123)
    v2=verifier_spec(x,"V2",123)
    assert v1["permutation_order"] != ["A","B","C","D"]
    assert v2["permutation_order"] != ["A","B","C","D"]
    assert v1["permutation_order"] != v2["permutation_order"]
    assert set(v1["display_to_canonical"].values()) == set("ABCD")


def test_majority_and_three_way_abstain():
    assert _majority(["A","A","B"]) == "A"
    assert _majority(["A","B","C"]) is None


def test_consensus_can_remove_direct_harm():
    rows={
        "q1":{
            "B1":rec("q1","B1","A","A",0.10),
            "D0":rec("q1","D0","B","A"),
            "V1":rec("q1","V1","A","A"),
            "V2":rec("q1","V2","A","A"),
        },
        "q2":{
            "B1":rec("q2","B1","B","A",0.10),
            "D0":rec("q2","D0","A","A"),
            "V1":rec("q2","V1","A","A"),
            "V2":rec("q2","V2","A","A"),
        },
    }
    direct=_policy_metrics(rows,0.20,False)
    cons=_policy_metrics(rows,0.20,True)
    assert direct["harms"] == 1
    assert cons["harms"] == 0
    assert cons["repairs"] == 1
