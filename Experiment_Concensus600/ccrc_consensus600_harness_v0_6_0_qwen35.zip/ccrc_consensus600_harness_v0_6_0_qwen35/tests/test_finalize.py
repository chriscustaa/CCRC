from harness.finalize import IMMUTABLE_TARGETS

def test_finalization_artifacts():
    assert "source_mmlu_test.parquet" in IMMUTABLE_TARGETS
    assert "policy_decisions.jsonl" in IMMUTABLE_TARGETS
    assert "summary.json" in IMMUTABLE_TARGETS
