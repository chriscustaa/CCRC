# CCRC Consensus600 v0.6.0 — Pre-Registration

## Hypothesis

A low first-pass decision margin identifies cases where extra independent inference has higher expected value. Blind consensus may retain D0 repairs while suppressing D0 harms.

## Dataset

600 questions from pinned MMLU test data (`cais/mmlu`, `all/test`) at revision:

`11e93aae807968eb444e8b46de5789e368ef4006`

Pinned parquet SHA-256:

`c08ff89872eac44b092e2e94a17d7a7c358f5a27c52241b60748830a81561c8b`

All prior SycoBench semantic stems are excluded. Order-dependent answer sets are excluded before sampling because V1/V2 permute options.

## Model/runtime

Qwen3.5-9B Q4_K_M. Thinking OFF. Temperature 0. top_p 1. penalties 0.

Runtime snapshot:

`d8ec616a61e2046592391ff4739e6e53048d9027a0669d24b1f6b1ca9567568b`

## Sensor

`g = top1 answer-letter logprob - top2 answer-letter logprob`

Frozen thresholds:

- primary: `theta = 0.20`
- secondary: `theta = 0.50`

No post-hoc threshold tuning on MMLU is permitted.

## Branches

- B1: first sensing answer
- D0: blind stateless re-derivation
- V1: blind neutral verifier, independently permuted answer order
- V2: blind neutral verifier, different deterministic permutation and neutral wording

B1 is excluded from the D0/V1/V2 majority.

No majority -> abstain.

## Policies

1. B1
2. unconditional D0
3. gated direct D0, theta=.20
4. gated blind consensus, theta=.20
5. gated direct D0, theta=.50
6. gated blind consensus, theta=.50

## Primary endpoints

- B1-wrong -> final-correct repairs
- B1-correct -> final-wrong harms
- net repairs minus harms
- abstentions
- coverage
- accuracy among answered
- resolved correct / total
- routed rate
- B1/D0 disagreement coverage
- simulated deployment calls and measured tokens
- D0/V1/V2 answer agreement and correctness correlation

## Primary kill rule

Kill blind consensus if theta=.20 consensus does not reduce direct-D0 harms while preserving positive net gain over B1.

## Interpretation boundary

This experiment tests adaptive routing in a known finite candidate space. It does not establish that next-token margins measure semantic correctness for open-ended responses.
