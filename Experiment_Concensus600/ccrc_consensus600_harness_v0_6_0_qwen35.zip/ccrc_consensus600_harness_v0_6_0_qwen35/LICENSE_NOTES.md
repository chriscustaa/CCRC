# License Notes

The harness code in this package is experiment scaffolding.

The experiment downloads MMLU data from the `cais/mmlu` dataset mirror. The dataset page identifies the MMLU dataset license as MIT. The original MMLU benchmark is associated with:

Dan Hendrycks, Collin Burns, Steven Basart, Andy Zou, Mantas Mazeika, Dawn Song, and Jacob Steinhardt,
“Measuring Massive Multitask Language Understanding,” ICLR 2021.

No MMLU question data is bundled inside this harness ZIP. The pinned source parquet is downloaded into the experiment directory during `prepare` and is included only if the user later returns the finalized experiment archive.
