from __future__ import annotations

from pathlib import Path
from typing import Any

from .prompts import baseline_messages, d0_messages, verifier_spec
from .runner import benchmark_parsed, benchmark_scores, decision_gap
from .util import canonical_json, read_json, read_jsonl, sha256_text


def validate_experiment(experiment_dir: Path, require_full: bool = False) -> dict[str, Any]:
    items = read_jsonl(experiment_dir / "items.jsonl")
    runs = read_jsonl(experiment_dir / "runs.jsonl")
    manifest = read_json(experiment_dir / "manifest.json")
    errors, warnings = [], []

    item_by = {x["source_id"]: x for x in items}
    if len(item_by) != len(items):
        errors.append("Duplicate source_id in items.jsonl")
    keys = [r.get("run_key") for r in runs]
    if len(keys) != len(set(keys)):
        errors.append("Duplicate run_key")
    run_by = {r["run_key"]: r for r in runs}

    frozen_model = (manifest.get("planned_model") or {}).get("model_id")
    frozen_snapshot = (manifest.get("planned_model") or {}).get("observed_snapshot_sha256")
    seed = int(manifest["selection"]["seed"])
    collect_threshold = float(manifest["routing"]["verifier_collection_threshold"])

    for r in runs:
        qid = r["question_id"]
        if qid not in item_by:
            errors.append(f"Unknown question_id: {qid}")
            continue
        item = item_by[qid]
        if r.get("model_id") != frozen_model:
            errors.append(f"Model ID drift: {r['run_key']}")
        if r.get("model_snapshot_sha256") != frozen_snapshot:
            errors.append(f"Runtime snapshot drift: {r['run_key']}")
        if r.get("reasoning_detected"):
            errors.append(f"Reasoning detected: {r['run_key']}")
        if float(r.get("temperature", -1)) != 0.0:
            errors.append(f"Temperature drift: {r['run_key']}")
        if float(r.get("top_p", -1)) != 1.0:
            errors.append(f"top_p drift: {r['run_key']}")
        if float(r.get("presence_penalty", -999)) != 0.0:
            errors.append(f"presence penalty drift: {r['run_key']}")
        if float(r.get("frequency_penalty", -999)) != 0.0:
            errors.append(f"frequency penalty drift: {r['run_key']}")

        branch = r["branch"]
        if branch == "B1":
            expected = baseline_messages(item)
            expected_map = {x:x for x in "ABCD"}
        elif branch == "D0":
            expected = d0_messages(item)
            expected_map = {x:x for x in "ABCD"}
        elif branch in {"V1","V2"}:
            spec = verifier_spec(item, branch, seed)
            expected = spec["messages"]
            expected_map = spec["display_to_canonical"]
            if r.get("permutation_order") != spec["permutation_order"]:
                errors.append(f"Permutation drift: {r['run_key']}")
        else:
            errors.append(f"Unknown branch: {branch}")
            continue

        if r.get("messages") != expected:
            errors.append(f"Prompt mismatch: {r['run_key']}")
        if r.get("display_to_canonical") != expected_map:
            errors.append(f"Display/canonical map drift: {r['run_key']}")
        if r.get("prompt_sha256") != sha256_text(canonical_json(expected)):
            errors.append(f"Prompt hash mismatch: {r['run_key']}")
        if any(m["role"] == "assistant" for m in r["messages"]):
            errors.append(f"Blind branch contains assistant history: {r['run_key']}")

        if benchmark_parsed(r) not in {"A","B","C","D"}:
            errors.append(f"Unparsed benchmark answer: {r['run_key']}")
        if r.get("correct_answer") != item["correct"]:
            errors.append(f"Ground-truth drift: {r['run_key']}")

    observed_qids = {r["question_id"] for r in runs}
    for qid in observed_qids:
        if f"{qid}|B1" not in run_by or f"{qid}|D0" not in run_by:
            errors.append(f"Observed block missing B1/D0: {qid}")
            continue
        b1 = run_by[f"{qid}|B1"]
        try:
            gap = decision_gap(benchmark_scores(b1))
        except Exception as exc:
            errors.append(f"Sensor gap failure {qid}: {exc}")
            continue
        if abs(float(b1.get("decision_gap")) - gap) > 1e-9:
            errors.append(f"Stored decision_gap mismatch: {qid}")
        need_verifiers = gap < collect_threshold
        for branch in ["V1","V2"]:
            present = f"{qid}|{branch}" in run_by
            if need_verifiers and not present:
                errors.append(f"Low-margin block missing {branch}: {qid}")
            if (not need_verifiers) and present:
                errors.append(f"High-margin block unexpectedly contains {branch}: {qid}")

    if require_full:
        if len(items) != 600:
            errors.append(f"Full experiment requires 600 items, observed {len(items)}")
        for qid in item_by:
            if f"{qid}|B1" not in run_by or f"{qid}|D0" not in run_by:
                errors.append(f"Full block missing B1/D0: {qid}")
        low = 0
        for qid in item_by:
            b = run_by.get(f"{qid}|B1")
            if b and float(b.get("decision_gap", 999)) < collect_threshold:
                low += 1
        expected_count = 2 * len(items) + 2 * low
        if len(runs) != expected_count:
            errors.append(f"Dynamic run-count mismatch: expected {expected_count}, observed {len(runs)}")

    return {
        "ok": not errors,
        "n_items": len(items),
        "n_runs": len(runs),
        "require_full": require_full,
        "errors": errors,
        "warnings": warnings,
    }
