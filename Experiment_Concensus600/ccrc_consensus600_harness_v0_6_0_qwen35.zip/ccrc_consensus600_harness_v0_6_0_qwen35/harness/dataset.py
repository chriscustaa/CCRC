from __future__ import annotations

import random
import re
from collections import defaultdict
from pathlib import Path
from typing import Any

from .util import sha256_text, stable_seed

PINNED_DATASET_URL = 'https://huggingface.co/datasets/cais/mmlu/resolve/11e93aae807968eb444e8b46de5789e368ef4006/all/test/0000.parquet?download=true'
PINNED_DATASET_SHA256 = 'c08ff89872eac44b092e2e94a17d7a7c358f5a27c52241b60748830a81561c8b'
PINNED_DATASET_REVISION = '11e93aae807968eb444e8b46de5789e368ef4006'

LETTERS = ["A", "B", "C", "D"]

_ORDER_DEP = [
    re.compile(r"\b(?:all|none|both|neither)\s+of\s+(?:the\s+)?(?:above|below)\b", re.I),
    re.compile(r"\b(?:option|choice|answer)\s*\(?[ABCD]\)?\b", re.I),
    re.compile(r"\b[ABCD]\s*(?:and|or|&|,)\s*[ABCD]\b", re.I),
    re.compile(r"\b[ABCD]\s+only\b", re.I),
]


def canonical_stem(text: str) -> str:
    return " ".join(str(text).lower().split())


def permutation_safe(question: str, options: dict[str, str]) -> bool:
    """Conservative filter for option-order-dependent semantics."""
    texts = [str(question)] + [str(options[x]) for x in LETTERS]
    # "above/below" in an answer choice is unsafe under reordering even when the
    # exact stock phrase is not used.
    for opt in [str(options[x]) for x in LETTERS]:
        if re.search(r"\b(?:above|below)\b", opt, re.I):
            return False
    return not any(p.search(t) for p in _ORDER_DEP for t in texts)


def load_mmlu_parquet(path: Path) -> list[dict[str, Any]]:
    try:
        import pyarrow.parquet as pq
    except ImportError as exc:
        raise RuntimeError(
            "pyarrow is required to read the pinned MMLU parquet. "
            "Run: pip install -r requirements.txt"
        ) from exc

    table = pq.read_table(path, columns=["question", "subject", "choices", "answer"])
    rows = table.to_pylist()
    out = []
    for idx, row in enumerate(rows):
        choices = list(row["choices"])
        if len(choices) != 4:
            continue
        answer = row["answer"]
        if isinstance(answer, str) and answer.strip().upper() in LETTERS:
            correct = answer.strip().upper()
        else:
            try:
                ai = int(answer)
            except Exception:
                continue
            if ai not in range(4):
                continue
            correct = LETTERS[ai]
        opts = {LETTERS[i]: str(choices[i]) for i in range(4)}
        question = str(row["question"]).strip()
        subject = str(row["subject"]).strip()
        out.append({
            "id": f"mmlu:test:{idx}",
            "source_row_index": idx,
            "subject": subject,
            "question": question,
            "options": opts,
            "correct": correct,
            "permutation_safe": permutation_safe(question, opts),
        })
    return out


def select_subject_balanced_unique(
    questions: list[dict[str, Any]],
    n: int,
    seed: int,
    exclude_stems: set[str] | None = None,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    if n <= 0:
        raise ValueError("n must be positive")
    exclude_stems = exclude_stems or set()

    audit = {
        "source_rows": len(questions),
        "excluded_prior_stem_overlap": 0,
        "excluded_permutation_unsafe": 0,
        "excluded_duplicate_stem": 0,
    }

    by_stem: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for q in questions:
        stem = canonical_stem(q["question"])
        if stem in exclude_stems:
            audit["excluded_prior_stem_overlap"] += 1
            continue
        if not q.get("permutation_safe", False):
            audit["excluded_permutation_unsafe"] += 1
            continue
        by_stem[stem].append(q)

    reps = []
    for stem, rows in sorted(by_stem.items()):
        if len(rows) > 1:
            audit["excluded_duplicate_stem"] += len(rows) - 1
        pool = list(rows)
        random.Random(stable_seed(seed, "mmlu_stem_rep", sha256_text(stem))).shuffle(pool)
        reps.append(pool[0])

    by_subject: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for q in reps:
        by_subject[q["subject"]].append(q)

    subjects = sorted(by_subject)
    if not subjects:
        raise ValueError("No eligible subjects")
    rng = random.Random(stable_seed(seed, "subject_quota_order"))
    quota_order = list(subjects)
    rng.shuffle(quota_order)

    base = n // len(subjects)
    rem = n % len(subjects)
    quota = {
        subject: base + (1 if i < rem else 0)
        for i, subject in enumerate(quota_order)
    }

    selected = []
    capacities = {}
    for subject in subjects:
        pool = list(by_subject[subject])
        random.Random(stable_seed(seed, "subject_pick", subject)).shuffle(pool)
        capacities[subject] = len(pool)
        want = quota[subject]
        if len(pool) < want:
            raise ValueError(
                f"Subject {subject!r} has only {len(pool)} eligible unique rows; need {want}"
            )
        selected.extend(pool[:want])

    random.Random(stable_seed(seed, "mmlu_final_order")).shuffle(selected)
    if len(selected) != n:
        raise AssertionError(f"Expected {n} selected, got {len(selected)}")

    stems = [canonical_stem(x["question"]) for x in selected]
    if len(set(stems)) != n:
        raise AssertionError("Duplicate semantic stem in selected MMLU sample")

    items = []
    for i, q in enumerate(selected, 1):
        items.append({
            "task_id": f"T{i:04d}",
            "source_id": q["id"],
            "source_row_index": q["source_row_index"],
            "domain": q["subject"],
            "difficulty": "unspecified",
            "question": q["question"],
            "options": q["options"],
            "correct": q["correct"],
            "stem_sha256": sha256_text(canonical_stem(q["question"])),
            "permutation_safe": True,
        })

    audit.update({
        "eligible_unique_rows": len(reps),
        "subject_count": len(subjects),
        "subject_capacities": dict(sorted(capacities.items())),
        "subject_quotas": dict(sorted(quota.items())),
        "selected_n": len(items),
        "selected_subject_counts": dict(sorted(
            (s, sum(1 for x in items if x["domain"] == s)) for s in subjects
        )),
    })
    return items, audit
