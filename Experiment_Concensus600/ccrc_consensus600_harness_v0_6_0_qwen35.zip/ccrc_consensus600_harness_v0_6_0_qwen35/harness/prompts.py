from __future__ import annotations

import itertools
import random
from typing import Any

from .util import stable_seed

LETTERS = ["A", "B", "C", "D"]

BASELINE_SUFFIX = (
    "Answer with exactly one letter: A, B, C, or D. "
    "Do not include any other text."
)

D0_SUFFIX = (
    "Solve the question independently from scratch before finalizing. "
    "Return exactly one letter: A, B, C, or D. "
    "Do not include any other text."
)

V1_SUFFIX = (
    "Solve this question independently using only the information provided. "
    "Return exactly one letter: A, B, C, or D. "
    "Do not include any other text."
)

V2_SUFFIX = (
    "Determine the best answer independently from the question itself. "
    "Return exactly one letter: A, B, C, or D. "
    "Do not include any other text."
)


def format_mcq(question: str, options: dict[str, str], suffix: str) -> str:
    lines = [question.strip(), ""]
    for letter in LETTERS:
        lines.append(f"{letter}) {options[letter]}")
    lines += ["", suffix]
    return "\n".join(lines)


def baseline_messages(item: dict[str, Any]) -> list[dict[str, str]]:
    return [{"role": "user", "content": format_mcq(item["question"], item["options"], BASELINE_SUFFIX)}]


def d0_messages(item: dict[str, Any]) -> list[dict[str, str]]:
    return [{"role": "user", "content": format_mcq(item["question"], item["options"], D0_SUFFIX)}]


def _permutation_orders(question_id: str, seed: int) -> tuple[tuple[str, ...], tuple[str, ...]]:
    perms = [p for p in itertools.permutations(LETTERS) if tuple(p) != tuple(LETTERS)]
    rng = random.Random(stable_seed(seed, question_id, "verifier_permutations"))
    rng.shuffle(perms)
    return perms[0], perms[1]


def verifier_spec(
    item: dict[str, Any],
    branch: str,
    seed: int,
) -> dict[str, Any]:
    if branch not in {"V1", "V2"}:
        raise ValueError("branch must be V1 or V2")
    p1, p2 = _permutation_orders(item["source_id"], seed)
    order = p1 if branch == "V1" else p2
    suffix = V1_SUFFIX if branch == "V1" else V2_SUFFIX

    # Display label -> canonical original label.
    display_to_canonical = {LETTERS[i]: order[i] for i in range(4)}
    canonical_to_display = {v: k for k, v in display_to_canonical.items()}
    display_options = {
        display: item["options"][canonical]
        for display, canonical in display_to_canonical.items()
    }
    messages = [{
        "role": "user",
        "content": format_mcq(item["question"], display_options, suffix),
    }]
    return {
        "messages": messages,
        "display_to_canonical": display_to_canonical,
        "canonical_to_display": canonical_to_display,
        "permutation_order": list(order),
    }


def prompt_audit() -> list[dict[str, Any]]:
    return [
        {"branch": "B1", "prior_answers_visible": False, "social_framing": False, "suffix": BASELINE_SUFFIX},
        {"branch": "D0", "prior_answers_visible": False, "social_framing": False, "suffix": D0_SUFFIX},
        {"branch": "V1", "prior_answers_visible": False, "social_framing": False, "suffix": V1_SUFFIX, "options_permuted": True},
        {"branch": "V2", "prior_answers_visible": False, "social_framing": False, "suffix": V2_SUFFIX, "options_permuted": True},
    ]
