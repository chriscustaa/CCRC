from __future__ import annotations

import random
import time
from pathlib import Path
from typing import Any

from .lmstudio import LMStudioClient
from .model_identity import resolve_model_strict
from .parsing import answer_candidate_logprobs, exact_one_letter, parse_mcq_letter
from .prompts import baseline_messages, d0_messages, verifier_spec
from .util import append_jsonl, canonical_json, read_jsonl, sha256_text, stable_seed

LETTERS = ["A", "B", "C", "D"]


def generate_with_transport_retry(client: LMStudioClient, retries: int, **kwargs: Any) -> dict[str, Any]:
    last = None
    for attempt in range(retries + 1):
        try:
            return client.generate(**kwargs)
        except Exception as exc:
            last = exc
            if attempt >= retries:
                break
            time.sleep(0.5 * (2 ** attempt))
    raise RuntimeError(f"Transport failed after {retries + 1} attempts: {last}")


def _call(client, cfg, model_id, messages, seed):
    result = generate_with_transport_retry(
        client=client,
        retries=int(cfg.get("transport_retries", 2)),
        transport=cfg.get("transport", "responses"),
        model=model_id,
        messages=messages,
        temperature=float(cfg.get("temperature", 0.0)),
        top_p=float(cfg.get("top_p", 1.0)),
        max_tokens=int(cfg.get("max_tokens", 128)),
        seed=seed,
        top_logprobs=int(cfg.get("top_logprobs", 20)),
        presence_penalty=float(cfg.get("presence_penalty", 0.0)),
        frequency_penalty=float(cfg.get("frequency_penalty", 0.0)),
    )
    if bool(cfg.get("require_reasoning_off", False)) and result.get("reasoning_detected"):
        raise RuntimeError("Reasoning-off invariant violated.")
    return result


def decision_gap(candidate_logprobs: dict[str, float | None]) -> float:
    vals = sorted(
        [float(v) for k, v in candidate_logprobs.items() if k in LETTERS and v is not None],
        reverse=True,
    )
    if len(vals) < 2:
        raise RuntimeError(
            "Sensor gap unavailable: fewer than two A/B/C/D candidates appeared in top_logprobs."
        )
    return vals[0] - vals[1]


def _remap_scores(
    display_scores: dict[str, float | None],
    display_to_canonical: dict[str, str],
) -> dict[str, float | None]:
    out = {x: None for x in LETTERS}
    for display, canonical in display_to_canonical.items():
        out[canonical] = display_scores.get(display)
    return out


def _record(
    *,
    cfg,
    item,
    branch,
    messages,
    result,
    seed,
    display_to_canonical=None,
    permutation_order=None,
):
    raw = result["text"]
    parsed_display = parse_mcq_letter(raw)
    identity = {x: x for x in LETTERS}
    mapping = display_to_canonical or identity
    parsed_canonical = mapping.get(parsed_display) if parsed_display else None
    display_scores = answer_candidate_logprobs(result.get("token_logprobs"))
    canonical_scores = _remap_scores(display_scores, mapping)

    rec = {
        "schema_version": "ccrc.consensus600.run.v0.6.0",
        "experiment_id": cfg["experiment_id"],
        "run_key": f"{item['source_id']}|{branch}",
        "task_id": item["task_id"],
        "question_id": item["source_id"],
        "source_row_index": item["source_row_index"],
        "domain": item["domain"],
        "difficulty": item["difficulty"],
        "branch": branch,
        "correct_answer": item["correct"],
        "messages": messages,
        "prompt_sha256": sha256_text(canonical_json(messages)),
        "prompt_hash_scope": "canonical_api_messages_pre_chat_template",
        "display_to_canonical": mapping,
        "permutation_order": permutation_order or LETTERS,
        "model_id": cfg["_resolved_model_id"],
        "model_snapshot_sha256": cfg.get("_model_snapshot_sha256"),
        "transport": cfg.get("transport", "responses"),
        "temperature": float(cfg.get("temperature", 0.0)),
        "top_p": float(cfg.get("top_p", 1.0)),
        "presence_penalty": float(cfg.get("presence_penalty", 0.0)),
        "frequency_penalty": float(cfg.get("frequency_penalty", 0.0)),
        "require_reasoning_off": bool(cfg.get("require_reasoning_off", False)),
        "reasoning_tokens": result.get("reasoning_tokens"),
        "reasoning_content_present": result.get("reasoning_content_present"),
        "reasoning_detected": result.get("reasoning_detected"),
        "seed": seed,
        "raw_output": raw,
        "parsed_display_first": parsed_display,
        "parsed_first": parsed_canonical,
        "format_compliant_first": exact_one_letter(raw),
        "correct_first": (parsed_canonical == item["correct"]) if parsed_canonical else None,
        "candidate_answer_logprobs_display": display_scores,
        "candidate_answer_logprobs": canonical_scores,
        "token_logprobs": result.get("token_logprobs"),
        "usage": result.get("usage"),
        "latency_s": result.get("latency_s"),
        "transport_response_meta": result.get("meta"),
        "transport_request_meta": result.get("request_meta"),
        "format_retry": None,
    }
    if branch == "B1":
        rec["decision_gap"] = decision_gap(canonical_scores)
    return rec


def _maybe_format_retry(*, client, cfg, model_id, record, item, seed):
    if record["parsed_first"] is not None or not bool(cfg.get("format_retry", True)):
        return
    retry_messages = list(record["messages"]) + [{
        "role": "user",
        "content": "Format reminder: Reply with exactly one letter: A, B, C, or D."
    }]
    result = _call(client, cfg, model_id, retry_messages, seed + 1)
    raw = result["text"]
    parsed_display = parse_mcq_letter(raw)
    mapping = record["display_to_canonical"]
    parsed = mapping.get(parsed_display) if parsed_display else None
    display_scores = answer_candidate_logprobs(result.get("token_logprobs"))
    canonical_scores = _remap_scores(display_scores, mapping)
    record["format_retry"] = {
        "messages": retry_messages,
        "prompt_sha256": sha256_text(canonical_json(retry_messages)),
        "raw_output": raw,
        "parsed_display": parsed_display,
        "parsed": parsed,
        "format_compliant": exact_one_letter(raw),
        "correct": (parsed == item["correct"]) if parsed else None,
        "candidate_answer_logprobs_display": display_scores,
        "candidate_answer_logprobs": canonical_scores,
        "token_logprobs": result.get("token_logprobs"),
        "usage": result.get("usage"),
        "reasoning_detected": result.get("reasoning_detected"),
    }
    if record["branch"] == "B1":
        record["decision_gap"] = decision_gap(canonical_scores)


def benchmark_parsed(record: dict[str, Any]) -> str | None:
    if record.get("parsed_first") is not None:
        return record["parsed_first"]
    return (record.get("format_retry") or {}).get("parsed")


def benchmark_scores(record: dict[str, Any]) -> dict[str, float | None]:
    if record.get("parsed_first") is None:
        retry = record.get("format_retry") or {}
        if retry.get("candidate_answer_logprobs"):
            return retry["candidate_answer_logprobs"]
    return record.get("candidate_answer_logprobs") or {x: None for x in LETTERS}


def run_consensus600(cfg, items, experiment_dir: Path, limit: int | None):
    client = LMStudioClient(
        cfg["lmstudio_base_url"], timeout_s=float(cfg.get("timeout_s", 120))
    )
    model_id, identity = resolve_model_strict(client, cfg)
    cfg = dict(cfg)
    cfg["_resolved_model_id"] = model_id
    cfg["_model_snapshot_sha256"] = identity["model_snapshot_sha256"]

    threshold = float((cfg.get("routing") or {}).get("verifier_collection_threshold", 0.50))
    run_path = experiment_dir / "runs.jsonl"
    existing = {r["run_key"]: r for r in read_jsonl(run_path)}
    todo = items[:limit] if limit else items
    item_order = list(todo)
    random.Random(stable_seed(int(cfg["seed"]), "consensus600_item_order")).shuffle(item_order)

    for item in item_order:
        qid = item["source_id"]
        block_seed = stable_seed(int(cfg["seed"]), qid, "consensus600_block")

        # B1 must be first: it is the sensing pass.
        bkey = f"{qid}|B1"
        b1 = existing.get(bkey)
        if b1 is None:
            msgs = baseline_messages(item)
            result = _call(client, cfg, model_id, msgs, block_seed)
            b1 = _record(
                cfg=cfg, item=item, branch="B1", messages=msgs,
                result=result, seed=block_seed,
            )
            _maybe_format_retry(
                client=client, cfg=cfg, model_id=model_id,
                record=b1, item=item, seed=block_seed,
            )
            if benchmark_parsed(b1) not in LETTERS:
                raise RuntimeError(f"B1 remained unparsable: {qid}")
            append_jsonl(run_path, b1)
            existing[bkey] = b1

        gap = b1.get("decision_gap")
        if gap is None:
            gap = decision_gap(benchmark_scores(b1))
            b1["decision_gap"] = gap

        branches = ["D0"]
        if float(gap) < threshold:
            branches += ["V1", "V2"]
        random.Random(stable_seed(int(cfg["seed"]), qid, "post_sensor_order")).shuffle(branches)

        for branch in branches:
            key = f"{qid}|{branch}"
            if key in existing:
                continue
            if branch == "D0":
                spec = {
                    "messages": d0_messages(item),
                    "display_to_canonical": {x: x for x in LETTERS},
                    "permutation_order": LETTERS,
                }
            else:
                spec = verifier_spec(item, branch, int(cfg["seed"]))

            result = _call(client, cfg, model_id, spec["messages"], block_seed)
            rec = _record(
                cfg=cfg,
                item=item,
                branch=branch,
                messages=spec["messages"],
                result=result,
                seed=block_seed,
                display_to_canonical=spec["display_to_canonical"],
                permutation_order=spec["permutation_order"],
            )
            _maybe_format_retry(
                client=client, cfg=cfg, model_id=model_id,
                record=rec, item=item, seed=block_seed,
            )
            if benchmark_parsed(rec) not in LETTERS:
                raise RuntimeError(f"{branch} remained unparsable: {qid}")
            append_jsonl(run_path, rec)
            existing[key] = rec
