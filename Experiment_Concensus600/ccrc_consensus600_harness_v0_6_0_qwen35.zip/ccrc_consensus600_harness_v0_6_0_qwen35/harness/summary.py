from __future__ import annotations

import csv
import math
from collections import Counter
from pathlib import Path
from typing import Any

from .runner import benchmark_parsed, benchmark_scores
from .util import read_jsonl, write_json, write_jsonl

LETTERS = ["A", "B", "C", "D"]


def _correct_margin(r):
    c = benchmark_scores(r)
    gt = r["correct_answer"]
    if c.get(gt) is None:
        return None
    others = [c[x] for x in LETTERS if x != gt and c.get(x) is not None]
    if not others:
        return None
    return float(c[gt]) - max(float(x) for x in others)


def _usage_tokens(r):
    usage = r.get("usage") or {}
    if usage.get("total_tokens") is not None:
        return int(usage["total_tokens"])
    a = usage.get("input_tokens", usage.get("prompt_tokens", 0)) or 0
    b = usage.get("output_tokens", usage.get("completion_tokens", 0)) or 0
    return int(a) + int(b)


def _majority(votes):
    clean = [x for x in votes if x in LETTERS]
    if len(clean) != 3:
        return None
    counts = Counter(clean)
    ans, n = counts.most_common(1)[0]
    return ans if n >= 2 else None


def _policy_metrics(
    rows,
    threshold: float,
    consensus: bool,
):
    repairs = harms = abstentions = correct = answered = 0
    routed = disagreements = 0
    policy_tokens = 0
    decisions = []

    # B1 is always paid.
    for qid, block in rows.items():
        b = block["B1"]
        d = block["D0"]
        gt = b["correct_answer"]
        b_ans = benchmark_parsed(b)
        d_ans = benchmark_parsed(d)
        gap = float(b["decision_gap"])
        policy_tokens += _usage_tokens(b)

        if gap >= threshold:
            final = b_ans
            route = "release_B1"
        else:
            routed += 1
            policy_tokens += _usage_tokens(d)
            if not consensus:
                final = d_ans
                route = "gated_D0"
            elif d_ans == b_ans:
                final = b_ans
                route = "B1_D0_consensus"
            else:
                disagreements += 1
                v1 = block.get("V1")
                v2 = block.get("V2")
                if v1 is not None:
                    policy_tokens += _usage_tokens(v1)
                if v2 is not None:
                    policy_tokens += _usage_tokens(v2)
                final = _majority([
                    d_ans,
                    benchmark_parsed(v1) if v1 else None,
                    benchmark_parsed(v2) if v2 else None,
                ])
                route = "blind_majority" if final is not None else "abstain"

        b_correct = b_ans == gt
        if final is None:
            abstentions += 1
        else:
            answered += 1
            final_correct = final == gt
            correct += int(final_correct)
            repairs += int((not b_correct) and final_correct)
            harms += int(b_correct and (not final_correct))

        decisions.append({
            "question_id": qid,
            "threshold": threshold,
            "policy": "consensus" if consensus else "direct_D0",
            "gap": gap,
            "B1": b_ans,
            "D0": d_ans,
            "V1": benchmark_parsed(block.get("V1")) if block.get("V1") else None,
            "V2": benchmark_parsed(block.get("V2")) if block.get("V2") else None,
            "final": final,
            "correct_answer": gt,
            "route": route,
        })

    n = len(rows)
    deployment_calls = n + routed + (2 * disagreements if consensus else 0)
    return {
        "threshold": threshold,
        "policy": "consensus" if consensus else "direct_D0",
        "n": n,
        "routed_n": routed,
        "routed_rate": routed / n if n else None,
        "B1_D0_disagreement_in_gate_n": disagreements if consensus else sum(
            float(block["B1"]["decision_gap"]) < threshold
            and benchmark_parsed(block["B1"]) != benchmark_parsed(block["D0"])
            for block in rows.values()
        ),
        "repairs": repairs,
        "harms": harms,
        "net_repairs_minus_harms": repairs - harms,
        "abstentions": abstentions,
        "coverage": answered / n if n else None,
        "accuracy_on_answered": correct / answered if answered else None,
        "resolved_correct_over_total": correct / n if n else None,
        "simulated_deployment_calls": deployment_calls,
        "extra_calls_over_B1": deployment_calls - n,
        "simulated_policy_tokens": policy_tokens,
        "decisions": decisions,
    }


def _unconditional_metrics(rows, branch):
    correct = 0
    for block in rows.values():
        r = block[branch]
        correct += benchmark_parsed(r) == r["correct_answer"]
    n = len(rows)
    return {
        "branch": branch,
        "n": n,
        "accuracy": correct / n if n else None,
        "deployment_calls": n,
        "tokens": sum(_usage_tokens(block[branch]) for block in rows.values()),
    }


def _pearson_binary(xs, ys):
    if len(xs) < 2:
        return None
    mx, my = sum(xs)/len(xs), sum(ys)/len(ys)
    vx = sum((x-mx)**2 for x in xs)
    vy = sum((y-my)**2 for y in ys)
    if vx == 0 or vy == 0:
        return None
    return sum((x-mx)*(y-my) for x,y in zip(xs,ys)) / math.sqrt(vx*vy)


def _branch_correlation(rows):
    low = [
        block for block in rows.values()
        if float(block["B1"]["decision_gap"]) < 0.50
        and "V1" in block and "V2" in block
    ]
    out = {"n_low50_with_verifiers": len(low), "pairs": {}}
    for a, b in [("D0","V1"),("D0","V2"),("V1","V2")]:
        ca = [int(benchmark_parsed(x[a]) == x[a]["correct_answer"]) for x in low]
        cb = [int(benchmark_parsed(x[b]) == x[b]["correct_answer"]) for x in low]
        agree = [
            int(benchmark_parsed(x[a]) == benchmark_parsed(x[b]))
            for x in low
        ]
        out["pairs"][f"{a}-{b}"] = {
            "correctness_phi_pearson": _pearson_binary(ca, cb),
            "answer_agreement_rate": sum(agree)/len(agree) if agree else None,
        }
    return out


def summarize(experiment_dir: Path):
    runs = read_jsonl(experiment_dir / "runs.jsonl")
    rows = {}
    for r in runs:
        rows.setdefault(r["question_id"], {})[r["branch"]] = r

    thresholds = [0.20, 0.50]
    policy_results = []
    policy_rows = []
    for t in thresholds:
        for consensus in [False, True]:
            m = _policy_metrics(rows, t, consensus)
            policy_rows.extend(m.pop("decisions"))
            policy_results.append(m)

    # Sensor bins / counterfactual D0 behavior.
    bins = [
        ("g<0.20", lambda g: g < 0.20),
        ("0.20<=g<0.50", lambda g: 0.20 <= g < 0.50),
        ("g>=0.50", lambda g: g >= 0.50),
    ]
    sensor_bins = {}
    for name, fn in bins:
        subset = [block for block in rows.values() if fn(float(block["B1"]["decision_gap"]))]
        if not subset:
            sensor_bins[name] = {"n": 0}
            continue
        repairs = harms = changes = bcorrect = dcorrect = 0
        for block in subset:
            b, d = block["B1"], block["D0"]
            ba, da, gt = benchmark_parsed(b), benchmark_parsed(d), b["correct_answer"]
            bc, dc = ba == gt, da == gt
            bcorrect += bc
            dcorrect += dc
            changes += ba != da
            repairs += (not bc) and dc
            harms += bc and (not dc)
        sensor_bins[name] = {
            "n": len(subset),
            "B1_accuracy": bcorrect / len(subset),
            "D0_accuracy": dcorrect / len(subset),
            "D0_change_rate": changes / len(subset),
            "repairs": repairs,
            "harms": harms,
        }

    write_jsonl(experiment_dir / "policy_decisions.jsonl", policy_rows)

    branch_acc = {
        "B1": _unconditional_metrics(rows, "B1"),
        "D0": _unconditional_metrics(rows, "D0"),
    }

    summary = {
        "schema_version": "ccrc.consensus600.summary.v0.6.0",
        "n_questions": len(rows),
        "n_runs": len(runs),
        "baselines": branch_acc,
        "sensor_bins": sensor_bins,
        "policies": policy_results,
        "branch_error_correlation": _branch_correlation(rows),
        "frozen_thresholds": {
            "primary": 0.20,
            "secondary": 0.50,
            "tuning_permitted": False,
        },
        "kill_rule": (
            "Kill blind consensus if the primary theta=0.20 consensus policy fails to "
            "reduce harmful flips relative to theta=0.20 direct D0 while preserving a "
            "positive net repairs-minus-harms gain over B1."
        ),
        "interpretation_boundary": (
            "This is a finite-choice controller test. The top-two answer-letter margin "
            "is not assumed to generalize directly to open-ended semantic correctness."
        ),
    }
    write_json(experiment_dir / "summary.json", summary)

    fields = [
        "run_key","question_id","domain","branch","correct_answer",
        "decision_gap","raw_output","parsed","correct_margin",
        "permutation_order","prompt_sha256",
    ]
    with (experiment_dir / "summary.csv").open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for r in runs:
            w.writerow({
                "run_key": r["run_key"],
                "question_id": r["question_id"],
                "domain": r["domain"],
                "branch": r["branch"],
                "correct_answer": r["correct_answer"],
                "decision_gap": r.get("decision_gap"),
                "raw_output": r["raw_output"],
                "parsed": benchmark_parsed(r),
                "correct_margin": _correct_margin(r),
                "permutation_order": json_safe_list(r.get("permutation_order")),
                "prompt_sha256": r["prompt_sha256"],
            })
    return summary


def json_safe_list(x):
    if x is None:
        return None
    return ",".join(str(v) for v in x)
