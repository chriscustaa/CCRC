# CCRC Consensus600 Harness v0.6.0 — Margin-Gated Blind Consensus

This is the **sixth experiment** and the first direct test of the adaptive inference controller.

The core question is no longer whether blind re-derivation can change an answer. Blind80 showed that it can, and that the effect is conditional on first-pass fragility. This experiment tests whether the **decision-margin sensor can allocate extra inference selectively, while a blind consensus stage preserves repairs and suppresses harms**.

## New dataset

SycoBench is now exhausted for clean semantic holdout work. v0.6 moves to **MMLU**, a separate 4-choice benchmark spanning 57 subjects.

Pinned source:

```text
dataset:  cais/mmlu
config:   all
split:    test
revision: 11e93aae807968eb444e8b46de5789e368ef4006
SHA-256:  c08ff89872eac44b092e2e94a17d7a7c358f5a27c52241b60748830a81561c8b
```

The harness selects **600 questions** with approximately equal per-subject quotas after:

1. exact canonical-stem exclusion of all 270 prior SycoBench items;
2. duplicate-stem removal;
3. conservative exclusion of questions whose answer choices are unsafe to permute (for example "all of the above" or choices that explicitly reference A/B/C/D).

## Frozen controller

Decision gap:

```text
g = logP(top A/B/C/D option) - logP(second A/B/C/D option)
```

Thresholds are frozen **before MMLU results are observed**:

```text
primary:   theta = 0.20
secondary: theta = 0.50
```

No threshold tuning is allowed.

Controller:

```text
B1 sensing pass
│
├─ g >= theta -> release B1
│
└─ g < theta -> blind D0
                 │
                 ├─ B1 = D0 -> release consensus
                 │
                 └─ B1 != D0 -> blind V1 + blind V2
                                   │
                                   ├─ majority(D0,V1,V2) -> release
                                   └─ 3-way split / invalid -> abstain
```

`B1` is never allowed back into the final three-vote majority.

### Verifiers

V1 and V2 receive only the original question. They never receive:

- B1;
- D0;
- explanations;
- provenance;
- accountability/audit language;
- a claimed correct answer.

Each gets a different deterministic permutation of the four choices. Output labels are remapped to the original canonical A/B/C/D before scoring.

Because the same model/runtime is used for all branches, V1/V2 are **decorrelated probes, not statistically independent judges**. The harness measures their pairwise answer agreement and correctness correlation.

## Research collection vs deployment cost

For analysis, D0 is collected on all 600 questions so unconditional D0 and high-margin controls are measurable.

V1/V2 are collected on every `g < 0.50` question. This provides enough data to estimate same-model branch correlation.

The reported *policy cost*, however, simulates the intended controller:

```text
calls(theta) = N + routed(theta) + 2 * disagreements(theta)
```

because production V1/V2 would be invoked only after gated B1/D0 disagreement.

The summary reports calls and measured tokens separately.

## Primary kill rule

Kill blind consensus if the `theta=0.20` consensus policy fails to:

1. reduce harmful flips relative to `theta=0.20` gated direct D0; **and**
2. preserve a positive net repairs-minus-harms gain over B1.

A higher selective accuracy caused only by abstaining is not sufficient; coverage and abstentions are mandatory metrics.

## Frozen comparisons

The full run produces:

- B1 baseline;
- unconditional D0;
- gated direct D0 at theta 0.20;
- gated blind consensus at theta 0.20;
- gated direct D0 at theta 0.50;
- gated blind consensus at theta 0.50;
- sensor-bin analysis (`g<.20`, `.20<=g<.50`, `g>=.50`);
- V1/V2/D0 branch-error correlation;
- calls and token cost.

## Environment

Keep the same Qwen3.5-9B Q4_K_M runtime:

```text
Thinking          OFF
temperature       0.0
top_p             1.0
presence_penalty  0.0
frequency_penalty 0.0
Responses API     primary
top_logprobs      20
```

Required runtime snapshot:

```text
d8ec616a61e2046592391ff4739e6e53048d9027a0669d24b1f6b1ca9567568b
```

## Setup

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item config.example.json config.json
```

If LM Studio authentication is enabled:

```powershell
$env:LM_API_TOKEN="YOUR_TOKEN"
```

## Run sequence

### 1. Doctor

Start with `"model_id": null`:

```powershell
python -m harness.cli doctor `
  --config config.json `
  --out experiment_consensus600/doctor.json
```

Copy the exact discovered Qwen3.5 model key into `config.json`, then rerun doctor. Do not continue unless it PASSes and matches runtime snapshot `d8ec616a61e2046592391ff4739e6e53048d9027a0669d24b1f6b1ca9567568b`.

### 2. Prepare

Supply the finalized `items.jsonl` from the three prior sample sets:

```powershell
python -m harness.cli prepare `
  --config config.json `
  --out experiment_consensus600 `
  --exclude-items `
    "C:\path\to\experiment_decomp30\items.jsonl" `
    "C:\path\to\experiment_review160\items.jsonl" `
    "C:\path\to\experiment_blind80\items.jsonl"
```

By default the harness downloads and hash-verifies the pinned 3.5 MB MMLU parquet. If you already have the exact pinned parquet, use `--dataset-file`.

### 3. Transport check

```powershell
python -m harness.cli transport-check `
  --config config.json `
  --experiment experiment_consensus600 `
  --n-items 2
```

This deliberately exercises B1, D0, V1 and V2 regardless of margin, but writes only `transport_check.json`, not experiment runs.

### 4. Acceptance

```powershell
python -m harness.cli run-consensus `
  --config config.json `
  --experiment experiment_consensus600 `
  --limit 4

python -m harness.cli validate --experiment experiment_consensus600
```

Acceptance run count is dynamic:

```text
2*4 + 2*(number of those 4 with g<0.50)
```

Send the validator output before the full run.

### 5. Full run

```powershell
python -m harness.cli run-consensus `
  --config config.json `
  --experiment experiment_consensus600
```

Full run count is also dynamic:

```text
1200 + 2*(number of the 600 with g<0.50)
```

Then:

```powershell
python -m harness.cli validate --experiment experiment_consensus600 --full
python -m harness.cli summarize --experiment experiment_consensus600
python -m harness.cli finalize --experiment experiment_consensus600
```

Zip finalized `experiment_consensus600` unchanged and return it.

## Boundary

This remains a **finite-choice architecture**. A top-two answer-letter gap is a decision-state sensor over an explicit candidate space. It must not be silently equated with semantic uncertainty in free-form generation.
