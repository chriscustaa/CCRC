# Dataset Notes — MMLU Consensus600

The experiment moves off SycoBench because its fresh semantic stems were effectively exhausted.

MMLU is used because it provides a large, fixed, four-choice candidate space across 57 subjects, which allows direct reuse of the decision-margin sensor without pretending that a free-form next-token gap is equivalent to semantic confidence.

Pinned source:

- repository/dataset: `cais/mmlu`
- configuration: `all`
- split: `test`
- revision: `11e93aae807968eb444e8b46de5789e368ef4006`
- parquet SHA-256: `c08ff89872eac44b092e2e94a17d7a7c358f5a27c52241b60748830a81561c8b`

The harness conservatively excludes questions unsafe for option-order permutation. This is necessary because V1 and V2 intentionally permute options to reduce simple same-label anchoring. Items containing constructs such as “all of the above,” “none of the above,” or explicit answer-label references are excluded before sampling.

MMLU is a long-standing public benchmark and may have appeared in model training data. This experiment is therefore **not** presented as a clean benchmark of model knowledge. Its purpose is held-out controller/generalization testing across a different question distribution.
